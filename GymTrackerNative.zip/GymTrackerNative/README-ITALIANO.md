# Gym Tracker — progetto Android nativo

Questo è un progetto Android nativo (Kotlin + Jetpack Compose), non una PWA e non un sito web. L'APK non è incluso: viene compilato dalla workflow GitHub Actions.

## Come ottenere l'APK solo dal telefono
1. Scarica e decomprimi `GymTrackerNative.zip` usando il gestore file del telefono.
2. Crea/accedi a un account GitHub e crea un repository nuovo chiamato `GymTracker`.
3. Carica i file e le cartelle del progetto nel repository mantenendo la struttura. In alternativa, da GitHub usa **Add file → Upload files** dal browser in modalità desktop.
4. Apri la scheda **Actions**, abilita le Actions se richiesto e avvia **Build Gym Tracker APK → Run workflow**.
5. Quando il workflow termina con il segno verde, apri l'esecuzione e scarica l'artifact **Gym-Tracker-APK**.
6. Estrai lo ZIP scaricato e apri `app-debug.apk` sul telefono. Android potrebbe chiedere di autorizzare l'installazione da quella fonte.

Nota: il nome `CHEST*` e `HPX*` è incerto nella trascrizione della scheda e va verificato. Il timer parte quando spunti una serie; recupero impostato a 90 secondi. I dati sono salvati localmente tramite SharedPreferences.
