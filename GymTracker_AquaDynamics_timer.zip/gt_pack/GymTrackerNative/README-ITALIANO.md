# GymTracker – timer recupero in background

Questa versione aggiunge un servizio Android in primo piano per il timer di recupero.

## Timer e notifiche
- Quando viene completata una serie, GymTracker avvia il timer di recupero da 90 secondi.
- Il timer continua anche quando l'app è in background o lo schermo è spento.
- La notifica persistente mostra il tempo rimanente e offre i comandi **Pausa**, **Riprendi** e **Ferma**.
- Su Android 13 e successivi l'app richiede il permesso per mostrare le notifiche.
- Su Android 14 e successivi il servizio dichiara il tipo `specialUse` con la relativa descrizione.

## OPPO Aqua Dynamics
La notifica usa la categoria stopwatch, è pubblica sulla schermata di blocco e si aggiorna ogni secondo. Questo rende il timer disponibile al sistema di notifiche Android. La visualizzazione specifica dentro Aqua Dynamics dipende però dalla versione ColorOS e dal supporto OPPO per le notifiche di app terze: non è possibile garantirla dal solo codice dell'app.

## Verifica
Il sorgente è stato aggiornato. In questo ambiente non è disponibile Android SDK/Gradle per compilare l'APK; prima dell'installazione va eseguita una build tramite GitHub Actions e provata sul dispositivo OPPO.
