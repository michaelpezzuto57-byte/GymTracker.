package it.gymtracker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Timer persistente: continua anche quando GymTracker è in background. */
class RestTimerService : Service() {
    private var timer: CountDownTimer? = null
    private var remainingMs: Long = 90_000L
    private var endAt: Long = 0L
    private var paused = false
    private val channelId = "gym_rest_timer"
    private val notificationId = 4201

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Timer recupero", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Conto alla rovescia del recupero tra le serie"
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTimer()
            ACTION_PAUSE -> pauseTimer()
            ACTION_RESUME -> resumeTimer()
            ACTION_START -> {
                remainingMs = intent.getIntExtra(EXTRA_SECONDS, 90).coerceIn(1, 600) * 1000L
                paused = false
                startForegroundCompat(buildNotification(remainingMs, false))
                runCountdown()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(notificationId, notification)
    }

    private fun runCountdown() {
        timer?.cancel()
        paused = false
        endAt = System.currentTimeMillis() + remainingMs
        updateNotification(remainingMs, false)
        timer = object : CountDownTimer(remainingMs, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMs = millisUntilFinished
                updateNotification(remainingMs, false)
            }
            override fun onFinish() {
                remainingMs = 0L
                updateNotification(0L, false, "Recupero terminato")
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }.start()
    }

    private fun pauseTimer() {
        if (paused || remainingMs <= 0L) return
        remainingMs = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)
        timer?.cancel()
        paused = true
        updateNotification(remainingMs, true)
    }

    private fun resumeTimer() {
        if (!paused || remainingMs <= 0L) return
        runCountdown()
    }

    private fun stopTimer() {
        timer?.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun actionIntent(action: String, requestCode: Int) = PendingIntent.getService(
        this, requestCode, Intent(this, RestTimerService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(ms: Long, isPaused: Boolean, message: String? = null): Notification {
        val seconds = ((ms + 999L) / 1000L).toInt()
        val time = "%d:%02d".format(seconds / 60, seconds % 60)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("GymTracker • Recupero")
            .setContentText(message ?: if (isPaused) "In pausa · $time" else "Tempo rimanente · $time")
            .setContentIntent(open)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setOngoing(message == null && ms > 0L)
        if (message == null) {
            if (isPaused) builder.addAction(android.R.drawable.ic_media_play, "Riprendi", actionIntent(ACTION_RESUME, 2))
            else builder.addAction(android.R.drawable.ic_media_pause, "Pausa", actionIntent(ACTION_PAUSE, 3))
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Ferma", actionIntent(ACTION_STOP, 1))
        }
        return builder.build()
    }

    private fun updateNotification(ms: Long, isPaused: Boolean, message: String? = null) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId, buildNotification(ms, isPaused, message))
    }

    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "it.gymtracker.app.timer.START"
        const val ACTION_STOP = "it.gymtracker.app.timer.STOP"
        const val ACTION_PAUSE = "it.gymtracker.app.timer.PAUSE"
        const val ACTION_RESUME = "it.gymtracker.app.timer.RESUME"
        const val EXTRA_SECONDS = "seconds"
    }
}

fun startRestTimer(context: Context, seconds: Int) {
    val intent = Intent(context, RestTimerService::class.java).setAction(RestTimerService.ACTION_START).putExtra(RestTimerService.EXTRA_SECONDS, seconds)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
}

fun stopRestTimer(context: Context) {
    val intent = Intent(context, RestTimerService::class.java).setAction(RestTimerService.ACTION_STOP)
    context.startService(intent)
}
