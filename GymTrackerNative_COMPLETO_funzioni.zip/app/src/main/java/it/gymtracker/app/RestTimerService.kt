package it.gymtracker.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat

class RestTimerService : Service() {
    private var timer: CountDownTimer? = null
    private var endAt: Long = 0L
    private val channelId = "gym_rest_timer"
    private val notificationId = 4201

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Timer recupero", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { timer?.cancel(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                val seconds = intent.getIntExtra(EXTRA_SECONDS, 90).coerceIn(1, 600)
                timer?.cancel()
                endAt = System.currentTimeMillis() + seconds * 1000L
                startForeground(notificationId, buildNotification(seconds))
                timer = object : CountDownTimer(seconds * 1000L, 1000L) {
                    override fun onTick(millisUntilFinished: Long) { updateNotification(((millisUntilFinished + 999) / 1000).toInt()) }
                    override fun onFinish() {
                        updateNotification(0, "Recupero terminato")
                        stopForeground(STOP_FOREGROUND_DETACH)
                        stopSelf()
                    }
                }.start()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(seconds: Int, message: String = "Recupero in corso"): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, RestTimerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("GymTracker • Timer")
            .setContentText(if (seconds > 0) "$message: ${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}" else message)
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(seconds > 0)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Ferma", stop)
            .build()
    }

    private fun updateNotification(seconds: Int, message: String = "Recupero in corso") {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId, buildNotification(seconds, message))
    }

    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "it.gymtracker.app.timer.START"
        const val ACTION_STOP = "it.gymtracker.app.timer.STOP"
        const val EXTRA_SECONDS = "seconds"
    }
}

fun startRestTimer(context: Context, seconds: Int) {
    val intent = Intent(context, RestTimerService::class.java).setAction(RestTimerService.ACTION_START).putExtra(RestTimerService.EXTRA_SECONDS, seconds)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
}

fun stopRestTimer(context: Context) {
    context.startService(Intent(context, RestTimerService::class.java).setAction(RestTimerService.ACTION_STOP))
}
