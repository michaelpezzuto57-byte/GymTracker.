# Gym Tracker – aggiornamento progressi e importazione

Questa versione del progetto mantiene le schede A/B/C, le schede personalizzate, il timer, il salvataggio delle serie e l'interfaccia nera/rossa.

## Novità aggiunte al codice

- **Storico dei carichi:** quando si termina un allenamento, i carichi inseriti negli esercizi vengono registrati con data, scheda ed esercizio.
- **Grafici per esercizio:** nella sezione Statistiche viene mostrato un grafico dell'andamento dei carichi registrati, con ultimo peso e numero di rilevazioni.
- **Anteprima OCR strutturata:** il testo letto da fotocamera o galleria viene analizzato per individuare righe nel formato `Panca piana 4x10` o `Panca piana 4 serie da 10`.
- **Correzione prima del salvataggio:** nome esercizio, numero di serie e ripetizioni sono modificabili nell'anteprima. La scheda viene salvata solo dopo conferma e con un nome diverso da A/B/C.

## Limiti da conoscere

L'OCR dipende dalla qualità e dalla disposizione del testo nella foto. La conversione automatica riconosce soprattutto il formato `nome esercizio + serie x ripetizioni`; le righe non riconosciute possono essere corrette nel campo del testo e poi analizzate nuovamente. I grafici iniziano a raccogliere punti da quando questa versione viene usata: non ricostruiscono i carichi passati.

## Verifica

Il sorgente è stato modificato, ma in questo ambiente non sono disponibili Android SDK e Gradle per eseguire una compilazione Android. Il progetto deve quindi essere compilato e provato in Android Studio o tramite GitHub Actions prima di installare l'APK.
