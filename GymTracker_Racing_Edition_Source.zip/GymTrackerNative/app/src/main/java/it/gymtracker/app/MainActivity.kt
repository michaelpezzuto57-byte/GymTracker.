package it.gymtracker.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF101010)
private val Panel2 = Color(0xFF181818)
private val Red = Color(0xFFFF1724)
private val RedDark = Color(0xFF8D0710)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFF9B9B9B)
private val routines = mapOf(
    "A" to listOf(Exercise("LEG PRESS",4,"10"), Exercise("PANCA PIANA",4,"10"), Exercise("LAT AVANTI",4,"10"), Exercise("ALZATE LAT",3,"12"), Exercise("PANCA SCOTT",4,"10"), Exercise("PUSH DOWN",3,"12"), Exercise("CRUNCH",3,"15"), Exercise("CRUNCH INVERSO",3,"15"), Exercise("PLANK",3,"30 sec")),
    "B" to listOf(Exercise("LENTO MANUBRI",4,"10"), Exercise("PULLEY",3,"10"), Exercise("LEG EX",3,"12"), Exercise("CROCI",3,"12"), Exercise("ALZATE POST",3,"10"), Exercise("CURL AL CAVO",3,"10"), Exercise("AB CRUNCH",3,"15"), Exercise("SIDE PLANK",3,"20 sec"), Exercise("INVERSI VERTICAL",3,"15")),
    "C" to listOf(Exercise("CHEST*",4,"10"), Exercise("REMATORE",3,"10"), Exercise("LEG CURL",3,"12"), Exercise("PUSH UP",4,"max"), Exercise("CURL MANUBRI",3,"10"), Exercise("FRENCH MANUBRI",3,"10"), Exercise("CRUNCH GAMBE SU",3,"15"), Exercise("CRUNCH INVERSO",3,"15"), Exercise("HPX*",3,"12"))
)
private data class Exercise(val name: String, val sets: Int, val reps: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RacingGymTracker(this) }
    }
}

@Composable
private fun RacingGymTracker(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var tab by remember { mutableStateOf("HOME") }
    var checks by remember { mutableStateOf(loadChecks(prefs, day)) }
    var seconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var startedAt by remember { mutableLongStateOf(0L) }
    var elapsed by remember { mutableIntStateOf(0) }
    var completedElapsed by remember { mutableIntStateOf(0) }
    var completedDone by remember { mutableIntStateOf(0) }
    var completedTotal by remember { mutableIntStateOf(0) }

    LaunchedEffect(timerActive) {
        while (timerActive && seconds > 0) {
            delay(1000)
            seconds--
        }
        if (seconds <= 0) timerActive = false
    }
    LaunchedEffect(tab, startedAt) {
        while (tab == "WORKOUT" && startedAt > 0L) {
            delay(1000)
            elapsed = ((System.currentTimeMillis() - startedAt) / 1000).toInt()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF090909), Black, Color(0xFF130507))))) {
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
                Header()
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    "HOME" -> HomeScreen(day, { day = it; prefs.edit().putString("day", it).apply(); checks = loadChecks(prefs, it) },
                        { tab = "WORKOUT"; if (startedAt == 0L) startedAt = System.currentTimeMillis() })
                    "WORKOUT" -> WorkoutScreen(day, checks, { updated, idx ->
                        checks = updated
                        prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                        if (updated[idx]) { seconds = 90; timerActive = true }
                    }, { finish ->
                        val total = routines[day]!!.sumOf { it.sets }
                        val done = checks.count { it }
                        val line = "Scheda $day • $done/$total serie • ${elapsed / 60} min ${elapsed % 60} sec"
                        completedDone = done; completedTotal = total; completedElapsed = elapsed
                        history = (listOf(line) + history.lines().filter { it.isNotBlank() }).take(50).joinToString("\n")
                        prefs.edit().putString("history", history).apply()
                        if (finish) {
                            checks = List(total) { false }
                            prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                            timerActive = false; seconds = 0; startedAt = 0L; elapsed = 0
                            tab = "RESULT"
                        }
                    }, seconds, timerActive, { timerActive = false; seconds = 0 })
                    "STORICO" -> HistoryScreen(history, { history = ""; prefs.edit().remove("history").apply() })
                    "RESULT" -> ResultScreen(completedDone, completedTotal, completedElapsed,
                        { tab = "WORKOUT"; startedAt = System.currentTimeMillis() },
                        { tab = "HOME" })
                    else -> HistoryScreen(history, { history = ""; prefs.edit().remove("history").apply() })
                }
                Spacer(Modifier.weight(1f))
                BottomNav(tab) { tab = it }
            }
            // Red racing slashes and subtle carbon-like diagonal accents.
            Row(Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { Box(Modifier.width(3.dp).height(42.dp).background(Brush.verticalGradient(listOf(Red, Color.Transparent)))) }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("✚", color = Red, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(8.dp))
                Column {
                    Text("GYM", color = Red, fontSize = 27.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, lineHeight = 27.sp)
                    Text("TRACKER", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, lineHeight = 22.sp)
                }
            }
            Text("TRAIN HARD • TRACK EVERYTHING", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        }
        Text("RS4", color = Color(0xFF777777), fontSize = 32.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Text("125", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.Bottom))
    }
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(2.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Red, RedDark, Color.Transparent))))
}

@Composable
private fun HomeScreen(day: String, onDay: (String) -> Unit, start: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text("IL TUO ALLENAMENTO", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Text("SCEGLI LA SCHEDA E INIZIA", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
        Spacer(Modifier.height(18.dp))
        val titles = mapOf("A" to "PETTO + TRICIPITI", "B" to "DORSO + BICIPITI", "C" to "GAMBE + ADDOMINALI")
        val subtitles = mapOf("A" to "SPINTA • FORZA", "B" to "TRAZIONE • CONTROLLO", "C" to "POTENZA • CORE")
        listOf("A", "B", "C").forEach { d ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Panel2, Black, Color(0xFF210509))))
                .border(1.dp, if (day == d) Red else RedDark, RoundedCornerShape(16.dp))
                .clickable { onDay(d) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(d, color = Red, fontSize = 46.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(titles[d]!!, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(subtitles[d]!!, color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    Text("${routines[d]!!.size} ESERCIZI  •  ${routines[d]!!.sumOf { it.sets }} SERIE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("›", color = Red, fontSize = 38.sp, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(10.dp))
        RacingButton("▶   INIZIA ALLENAMENTO", start)
    }
}

@Composable
private fun WorkoutScreen(day: String, checks: List<Boolean>, onChecks: (List<Boolean>, Int) -> Unit,
                          finish: (Boolean) -> Unit, seconds: Int, timerActive: Boolean, stopTimer: () -> Unit) {
    val exercises = routines[day]!!
    val total = exercises.sumOf { it.sets }
    val done = checks.count { it }
    var selected by remember(day) { mutableIntStateOf(0) }
    val ex = exercises[selected]
    val startIndex = exercises.take(selected).sumOf { it.sets }
    Column(Modifier.fillMaxWidth().weight(1f, fill = false)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SCHEDA $day", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Text("SESSIONE RACING • $done / $total SERIE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Text("${(done * 100 / total)}%", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Red, trackColor = Panel2)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            exercises.forEachIndexed { i, item ->
                Box(Modifier.weight(1f).height(5.dp).clip(CircleShape).background(if (i == selected) Red else Panel2).clickable { selected = i })
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(Panel2, Black, Color(0xFF26070A))))
            .border(1.dp, RedDark, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(ex.name.replace("*", ""), color = White, fontSize = 19.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Text("ESERCIZIO ${selected + 1} DI ${exercises.size}", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("${ex.sets} SERIE  ×  ${ex.reps} RIPETIZIONI", color = Muted, fontSize = 11.sp)
            }
            Text("✚", color = Red, fontSize = 32.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(12.dp))
        Text("SERIE: ${checks.subList(startIndex, startIndex + ex.sets).count { it }} / ${ex.sets}", color = White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            itemsIndexed((0 until ex.sets).toList()) { s, _ ->
                val idx = startIndex + s
                val checked = checks.getOrElse(idx) { false }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (checked) Color(0xFF21090C) else Panel)
                    .border(1.dp, if (checked) Red else Color(0xFF333333), RoundedCornerShape(12.dp))
                    .clickable {
                        val updated = checks.toMutableList(); updated[idx] = !checked; onChecks(updated, idx)
                    }.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(27.dp).clip(CircleShape).background(if (checked) Red else Color.Transparent)
                        .border(2.dp, if (checked) Red else Muted, CircleShape), contentAlignment = Alignment.Center) {
                        if (checked) Text("✓", color = Black, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text("SERIE ${s + 1}", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${ex.reps} rip.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (checked) "✓" else "○", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        if (timerActive && seconds > 0) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF21070A)).border(1.dp, Red, RoundedCornerShape(14.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("◷", color = Red, fontSize = 27.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("RECUPERO AUTOMATICO", color = White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Text(String.format("%02d:%02d", seconds / 60, seconds % 60), color = Red, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                TextButton(onClick = stopTimer) { Text("SALTA", color = White) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { selected = (selected - 1).coerceAtLeast(0) }, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, RedDark)) { Text("INDIETRO", color = White, fontSize = 11.sp) }
            Button(onClick = { if (selected < exercises.lastIndex) selected++ else finish(true) },
                modifier = Modifier.weight(1.4f), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                Text(if (selected < exercises.lastIndex) "PROSSIMO  ›" else "COMPLETA", color = White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }
        TextButton(onClick = { finish(true) }, modifier = Modifier.fillMaxWidth()) { Text("TERMINA ALLENAMENTO", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun HistoryScreen(history: String, clear: () -> Unit) {
    Column(Modifier.fillMaxWidth().weight(1f, fill = false)) {
        Text("STORICO", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Text("LE TUE SESSIONI SALVATE", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (history.isBlank()) Text("Nessun allenamento registrato.", color = Muted)
        else LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(12.dp)).background(Panel)
                    .border(1.dp, RedDark, RoundedCornerShape(12.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🏆", fontSize = 20.sp); Spacer(Modifier.width(10.dp)); Text(line, color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        OutlinedButton(onClick = clear, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, RedDark)) { Text("CANCELLA CRONOLOGIA", color = Red) }
    }
}

@Composable
private fun ResultScreen(done: Int, total: Int, elapsed: Int, repeat: () -> Unit, home: () -> Unit) {
    Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("🏆", fontSize = 70.sp)
        Text("ALLENAMENTO", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Text("COMPLETATO!", color = Red, fontSize = 32.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).border(1.dp, Red, RoundedCornerShape(16.dp)).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("SERIE", "$done/$total")
            Stat("TEMPO", "${elapsed / 60}:${(elapsed % 60).toString().padStart(2, '0')}")
        }
        Spacer(Modifier.height(28.dp))
        RacingButton("↻   RIPETI", repeat)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = home, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Red)) { Text("⌂   TORNA ALLA HOME", color = White, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun RacingButton(label: String, action: () -> Unit) {
    Button(onClick = action, modifier = Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(topStart = 22.dp, bottomEnd = 22.dp, topEnd = 5.dp, bottomStart = 5.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Red)) {
        Text(label, color = White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp)
    }
}

@Composable
private fun BottomNav(tab: String, select: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp).border(BorderStroke(1.dp, Color(0xFF333333)), RoundedCornerShape(12.dp))
        .background(Black, RoundedCornerShape(12.dp)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf("HOME" to "⌂", "WORKOUT" to "✚", "STORICO" to "▥", "RESULT" to "♛").forEach { (name, icon) ->
            Column(Modifier.weight(1f).clickable { select(if (name == "RESULT") "STORICO" else name) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(icon, color = if (tab == name) Red else Muted, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text(if (name == "RESULT") "RISULTATI" else name, color = if (tab == name) Red else Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun loadChecks(prefs: android.content.SharedPreferences, day: String): List<Boolean> {
    val total = routines[day]!!.sumOf { it.sets }
    return try {
        val arr = JSONArray(prefs.getString("checks_$day", "[]"))
        List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false }
    } catch (_: Exception) { List(total) { false } }
}
