package it.gymtracker.app

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.OutlinedTextField
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF111111)
private var Accent = Color(0xFFFF101B)
private val White = Color(0xFFF4F4F4)
private val Muted = Color(0xFFB8B8B8)

data class Exercise(val name: String, val sets: Int, val reps: String, val art: Int, val muscle: Int)

private val routines = mapOf(
    "A" to listOf(
        Exercise("LEG PRESS",4,"10",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PANCA PIANA",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("LAT AVANTI",4,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("ALZATE LAT",3,"12",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("PANCA SCOTT",4,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("PUSH DOWN",3,"12",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("PLANK",3,"30 sec",R.drawable.leg_press,R.drawable.leg_press_muscle)
    ),
    "B" to listOf(
        Exercise("LENTO MANUBRI",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("PULLEY",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG EX",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("CROCI",3,"12",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("ALZATE POST",3,"10",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("CURL AL CAVO",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("AB CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("SIDE PLANK",3,"20 sec",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("INVERSI VERTICAL",3,"15",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle)
    ),
    "C" to listOf(
        Exercise("CHEST*",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("REMATORE",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG CURL",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PUSH UP",4,"max",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CURL MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("FRENCH MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH GAMBE SU",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("HPX*",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle)
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var screen by remember { mutableStateOf("WORKOUT") }
    var customSheets by remember { mutableStateOf(loadCustomSheets(prefs)) }
    var checks by remember { mutableStateOf(loadChecks(prefs, day, customSheets)) }
    var restSeconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var weightRecords by remember { mutableStateOf(loadWeightRecords(prefs)) }
    var showImport by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf("") }
    var importedName by remember { mutableStateOf("NUOVA SCHEDA") }
    var ocrBusy by remember { mutableStateOf(false) }
    var importedExercises by remember { mutableStateOf<List<Exercise>>(emptyList()) }
    var profileName by remember { mutableStateOf(prefs.getString("profile_name", "Atleta") ?: "Atleta") }
    var profileGoal by remember { mutableStateOf(prefs.getString("profile_goal", "Migliorare la forza") ?: "Migliorare la forza") }
    var selectedTheme by remember { mutableStateOf(prefs.getString("theme", "ROSSO") ?: "ROSSO") }
    var customHue by remember { mutableFloatStateOf(prefs.getFloat("custom_hue", 0f)) }
    Accent = when (selectedTheme) {
        "VERDE" -> Color(0xFF39D353)
        "BLU" -> Color(0xFF268BFF)
        "VIOLA" -> Color(0xFFB45CFF)
        "PERSONALIZZATO" -> Color(android.graphics.Color.HSVToColor(floatArrayOf(customHue, 0.88f, 1f)))
        else -> Color(0xFFFF101B)
    }

    fun recognizeImage(image: InputImage) {
        ocrBusy = true
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result -> ocrText = result.text; importedExercises = parseImportedExercises(result.text); showImport = true; ocrBusy = false }
            .addOnFailureListener { ocrText = ""; importedExercises = emptyList(); showImport = true; ocrBusy = false }
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try { recognizeImage(InputImage.fromFilePath(context, uri)) } catch (_: Exception) { ocrText = ""; importedExercises = emptyList(); showImport = true }
    }
    val cameraPicker = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) recognizeImage(InputImage.fromBitmap(bitmap, 0))
    }

    LaunchedEffect(timerActive, restSeconds) {
        while (timerActive && restSeconds > 0) { delay(1000); restSeconds -= 1 }
        if (restSeconds == 0) timerActive = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Black, surface = Panel, onSurface = White)) {
        Column(
            Modifier.fillMaxSize().background(Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.gym_header),
                contentDescription = "Gym Tracker - Goku Black",
                modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("WORKOUT", "STORICO").forEach { tab ->
                    Button(
                        onClick = { screen = tab },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (screen == tab) Accent else Color(0xFF171717))
                    ) { Text(tab, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                }
            }
            Spacer(Modifier.height(9.dp))

            when (screen) {
                "WORKOUT" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        (listOf("A", "B", "C") + customSheets.keys).forEach { d ->
                            Button(
                                onClick = { day = d; prefs.edit().putString("day", d).apply(); checks = loadChecks(prefs, d, customSheets) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (day == d) Accent else Color(0xFF171717))
                            ) { Text("SCHEDA $d", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { cameraPicker.launch(null) }, modifier = Modifier.weight(1f)) { Text("FOTOCAMERA", color = Accent, fontSize = 11.sp) }
                        OutlinedButton(onClick = { galleryPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("GALLERIA", color = Accent, fontSize = 11.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    val exercises = customSheets[day] ?: routines[day] ?: emptyList()
                    val total = exercises.sumOf { it.sets }
                    val done = checks.count { it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("▮", color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("PROGRESSO  $done / $total SERIE", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),
                        color = Accent, trackColor = Color(0xFF292020)
                    )
                    Spacer(Modifier.height(10.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                        itemsIndexed(exercises) { exIndex, ex ->
                            val start = exercises.take(exIndex).sumOf { it.sets }
                            ExerciseCard(
                                ex, checks, start,
                                weight = prefs.getString("weight_${day}_${ex.name}", "") ?: "",
                                onWeightChange = { value -> prefs.edit().putString("weight_${day}_${ex.name}", value).apply() }
                            ) { idx, checked ->
                                val updated = checks.toMutableList(); updated[idx] = checked; checks = updated
                                prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                                if (checked) { restSeconds = 90; timerActive = true }
                            }
                        }
                        item {
                            Button(
                                onClick = {
                                    val completed = checks.count { it }
                                    val entry = "Scheda $day — $completed/$total serie completate"
                                    val sessionRecords = exercises.mapNotNull { ex ->
                                        val kg = prefs.getString("weight_${day}_${ex.name}", "")?.replace(',', '.')?.toFloatOrNull()
                                        if (kg != null && kg > 0f) WeightRecord(System.currentTimeMillis(), day, ex.name, kg) else null
                                    }
                                    weightRecords = (weightRecords + sessionRecords).takeLast(500)
                                    saveWeightRecords(prefs, weightRecords)
                                    history = (listOf(entry) + history.lines().filter { it.isNotBlank() }).take(50).joinToString("\n")
                                    prefs.edit().putString("history", history).apply()
                                    checks = List(total) { false }
                                    prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                                    timerActive = false; restSeconds = 0; screen = "STORICO"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) { Text("TERMINA ALLENAMENTO", fontWeight = FontWeight.Black) }
                        }
                    }
                }
                "STORICO" -> {
                    Text("CRONOLOGIA", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    if (history.isBlank()) Text("Gli allenamenti conclusi appariranno qui.", color = Muted)
                    else LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Text(line, color = White, modifier = Modifier.padding(14.dp))
                            }
                        }
                    }
                    OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }, modifier = Modifier.fillMaxWidth()) {
                        Text("CANCELLA CRONOLOGIA", color = Accent)
                    }
                }
                "STATISTICHE" -> {
                    val sessions = history.lines().count { it.isNotBlank() }
                    val completedSets = history.lines().sumOf { line -> Regex("(\\d+)/(\\d+) serie").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
                    Text("STATISTICHE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("I tuoi progressi registrati", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("ALLENAMENTI", sessions.toString(), Modifier.weight(1f))
                        StatTile("SERIE COMPLETATE", completedSets.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    StatTile("SCHEDE DISPONIBILI", (3 + customSheets.size).toString(), Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Text("ANDAMENTO DEI CARICHI", color = Accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (weightRecords.isEmpty()) {
                        Text("Inserisci un carico e termina un allenamento per iniziare a registrare i progressi.", color = Muted, fontSize = 12.sp)
                    } else {
                        val byExercise = weightRecords.groupBy { it.exercise }.toList().sortedBy { it.first }
                        LazyColumn(Modifier.heightIn(max = 260.dp)) {
                            itemsIndexed(byExercise) { _, pair ->
                                val values = pair.second.sortedBy { it.timestamp }
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Column(Modifier.padding(10.dp)) {
                                        Text(pair.first, color = White, fontWeight = FontWeight.Bold)
                                        Text("Ultimo carico: ${"%.1f".format(java.util.Locale.ITALIAN, values.last().kg)} kg • ${values.size} rilevazioni", color = Muted, fontSize = 11.sp)
                                        WeightTrendChart(values.map { it.kg })
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("ULTIMI ALLENAMENTI", color = Accent, fontWeight = FontWeight.Bold)
                    if (history.isBlank()) Text("Completa un allenamento per iniziare a vedere i tuoi progressi.", color = Muted, modifier = Modifier.padding(top = 8.dp))
                    else LazyColumn(Modifier.weight(1f)) { itemsIndexed(history.lines().filter { it.isNotBlank() }.take(10)) { _, line -> Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(line, color = White, modifier = Modifier.padding(12.dp)) } } }
                }
                "TRAGUARDI" -> {
                    val sessions = history.lines().count { it.isNotBlank() }
                    val completedSets = history.lines().sumOf { line -> Regex("(\\d+)/(\\d+) serie").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0 }
                    Text("TRAGUARDI", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Ogni allenamento è un passo avanti.", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    Achievement("Primo allenamento", sessions, 1)
                    Achievement("5 allenamenti", sessions, 5)
                    Achievement("10 allenamenti", sessions, 10)
                    Achievement("50 serie completate", completedSets, 50)
                    Achievement("100 serie completate", completedSets, 100)
                    Spacer(Modifier.weight(1f))
                }
                "PROFILO" -> {
                    Text("PROFILO", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Personalizza la tua esperienza", color = Muted)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(value = profileName, onValueChange = { profileName = it; prefs.edit().putString("profile_name", it).apply() }, label = { Text("Nome atleta") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = profileGoal, onValueChange = { profileGoal = it; prefs.edit().putString("profile_goal", it).apply() }, label = { Text("Obiettivo") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Spacer(Modifier.height(12.dp))
                    Text("TEMA", color = Accent, fontWeight = FontWeight.Bold)
                    Text("Scegli il colore principale", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    val themeOptions = listOf("ROSSO", "VERDE", "BLU", "VIOLA")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        themeOptions.forEach { option ->
                            val c = when(option) { "VERDE" -> Color(0xFF39D353); "BLU" -> Color(0xFF268BFF); "VIOLA" -> Color(0xFFB45CFF); else -> Color(0xFFFF101B) }
                            Button(onClick = { selectedTheme = option; prefs.edit().putString("theme", option).apply() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 2.dp, vertical = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selectedTheme == option) c else Color(0xFF252525))) { Text(option, fontSize = 9.sp, color = White) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("COLORE PERSONALIZZATO", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Slider(value = customHue, onValueChange = { customHue = it; selectedTheme = "PERSONALIZZATO"; prefs.edit().putFloat("custom_hue", it).putString("theme", "PERSONALIZZATO").apply() }, valueRange = 0f..360f, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                    Text("Anteprima del colore selezionato", color = Accent, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                }
                else -> { Spacer(Modifier.weight(1f)) }
            }

            Row(
                Modifier.fillMaxWidth().background(Color(0xFF090909)).padding(top = 7.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("HOME", "STATISTICHE", "TRAGUARDI", "PROFILO").forEachIndexed { index, label ->
                    val target = when (index) { 0 -> "WORKOUT"; 1 -> "STATISTICHE"; 2 -> "TRAGUARDI"; else -> "PROFILO" }
                    TextButton(onClick = { screen = target }) {
                        Text(label, color = if ((index == 0 && screen == "WORKOUT") || (index == 1 && screen == "STATISTICHE") || (index == 2 && screen == "TRAGUARDI") || (index == 3 && screen == "PROFILO")) Accent else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false },
                containerColor = Panel,
                title = { Text("CONTROLLA LA SCHEDA", color = Accent, fontWeight = FontWeight.Black) },
                text = {
                    Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                        Text("Controlla e correggi il testo riconosciuto prima di salvarlo.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = importedName, onValueChange = { importedName = it }, label = { Text("Nome della nuova scheda") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = ocrText, onValueChange = { value -> ocrText = value; importedExercises = parseImportedExercises(value) }, label = { Text("Testo riconosciuto (modificabile)") }, minLines = 4, maxLines = 7)
                        Text("ESERCIZI RICONOSCIUTI — CORREGGI I CAMPI", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                        if (importedExercises.isEmpty()) Text("Nessun esercizio riconosciuto. Usa il formato: Panca piana 4x10.", color = Muted, fontSize = 11.sp)
                        importedExercises.forEachIndexed { index, ex ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1B1B)), modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Column(Modifier.padding(7.dp)) {
                                    OutlinedTextField(value = ex.name, onValueChange = { value -> importedExercises = importedExercises.toMutableList().also { it[index] = ex.copy(name = value.uppercase()) } }, label = { Text("Esercizio") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(value = ex.sets.toString(), onValueChange = { value -> value.toIntOrNull()?.let { n -> if (n in 1..20) importedExercises = importedExercises.toMutableList().also { it[index] = ex.copy(sets = n) } } }, label = { Text("Serie") }, singleLine = true, modifier = Modifier.weight(1f))
                                        OutlinedTextField(value = ex.reps, onValueChange = { value -> importedExercises = importedExercises.toMutableList().also { it[index] = ex.copy(reps = value.take(16)) } }, label = { Text("Ripetizioni") }, singleLine = true, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = importedExercises.filter { it.name.isNotBlank() && it.sets in 1..20 && it.reps.isNotBlank() }
                        val newName = importedName.trim()
                        val reservedName = newName.equals("A", true) || newName.equals("B", true) || newName.equals("C", true)
                        if (newName.isNotBlank() && !reservedName && parsed.isNotEmpty()) {
                            customSheets = customSheets + (newName to parsed)
                            saveCustomSheets(prefs, customSheets)
                            day = newName; prefs.edit().putString("day", day).apply()
                            checks = loadChecks(prefs, day, customSheets)
                            prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                            showImport = false
                        }
                    }) { Text("SALVA NUOVA SCHEDA", color = Accent) }
                },
                dismissButton = { TextButton(onClick = { showImport = false }) { Text("ANNULLA", color = White) } }
            )
        }

        if (timerActive && restSeconds > 0) {
            AlertDialog(
                onDismissRequest = { timerActive = false }, containerColor = Panel,
                title = { Text("RECUPERO", color = Accent, fontWeight = FontWeight.Black) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60), color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                        Text("Respira. La prossima serie ti aspetta.", color = Muted)
                    }
                },
                confirmButton = { TextButton(onClick = { timerActive = false; restSeconds = 0 }) { Text("SALTA", color = Accent) } },
                dismissButton = { TextButton(onClick = { timerActive = false }) { Text("NASCONDI", color = White) } }
            )
        }
    }
}

@Composable
private fun ExerciseCard(
    ex: Exercise, checks: List<Boolean>, start: Int,
    weight: String, onWeightChange: (String) -> Unit,
    onCheck: (Int, Boolean) -> Unit
) {
    var weightText by remember(ex.name, weight) { mutableStateOf(weight) }
    Box(
        Modifier.fillMaxWidth().height(178.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, Accent, RoundedCornerShape(20.dp))
    ) {
        Image(painterResource(ex.art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.48f)))
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(ex.muscle), contentDescription = null,
                modifier = Modifier.width(66.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(7.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(ex.name, color = White, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text("${ex.sets} serie × ${ex.reps} ripetizioni", color = Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = weightText,
                    onValueChange = { value ->
                        val filtered = value.filter { it.isDigit() || it == '.' || it == ',' }.take(7)
                        weightText = filtered
                        onWeightChange(filtered)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    singleLine = true,
                    label = { Text("Carico (kg)", fontSize = 10.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent, unfocusedBorderColor = Muted,
                        focusedLabelColor = Accent, unfocusedLabelColor = Muted, cursorColor = Accent
                    )
                )
                Spacer(Modifier.height(3.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    repeat(ex.sets) { s ->
                        val idx = start + s
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = checks.getOrElse(idx) { false },
                                onCheckedChange = { onCheck(idx, it) },
                                modifier = Modifier.size(30.dp),
                                colors = CheckboxDefaults.colors(checkedColor = Accent, uncheckedColor = Muted, checkmarkColor = White)
                            )
                            Text("${s + 1}", color = if (checks.getOrElse(idx) { false }) Accent else White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun loadChecks(
    prefs: android.content.SharedPreferences,
    day: String,
    customSheets: Map<String, List<Exercise>>
): List<Boolean> {
    val total = (customSheets[day] ?: routines[day] ?: emptyList()).sumOf { it.sets }
    return try {
        val arr = JSONArray(prefs.getString("checks_$day", "[]"))
        List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false }
    } catch (_: Exception) { List(total) { false } }
}


private fun parseImportedExercises(text: String): List<Exercise> {
    return text.lines().mapNotNull { line ->
        val clean = line.trim().replace(Regex("^\\d+[.)]\\s*"), "").trim('-', '•', '·', '*', ' ')
        val match = Regex("^(.+?)\\s*(?:[-:：]\\s*)?(\\d{1,2})\\s*[xX×]\\s*(\\d{1,3}(?:\\s*(?:sec|s|min))?)$", RegexOption.IGNORE_CASE).find(clean)
            ?: Regex("^(.+?)\\s+(\\d{1,2})\\s+serie\\s+(?:da\\s+)?(\\d{1,3})$", RegexOption.IGNORE_CASE).find(clean)
        if (match != null && match.groupValues[1].isNotBlank()) {
            Exercise(match.groupValues[1].trim().uppercase(), match.groupValues[2].toInt().coerceIn(1, 20), match.groupValues[3].trim(), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
        } else null
    }.distinctBy { it.name }.take(40)
}

private fun loadCustomSheets(prefs: android.content.SharedPreferences): Map<String, List<Exercise>> {
    return try {
        val root = org.json.JSONObject(prefs.getString("custom_sheets", "{}") ?: "{}")
        val result = linkedMapOf<String, List<Exercise>>()
        root.keys().forEach { key ->
            val arr = root.getJSONArray(key)
            result[key] = (0 until arr.length()).map { i ->
                val item = arr.getJSONObject(i)
                Exercise(item.getString("name"), item.getInt("sets"), item.getString("reps"), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
            }
        }
        result
    } catch (_: Exception) { emptyMap() }
}

private fun saveCustomSheets(prefs: android.content.SharedPreferences, sheets: Map<String, List<Exercise>>) {
    val root = org.json.JSONObject()
    sheets.forEach { (name, exercises) ->
        val arr = JSONArray()
        exercises.forEach { ex -> arr.put(org.json.JSONObject().put("name", ex.name).put("sets", ex.sets).put("reps", ex.reps)) }
        root.put(name, arr)
    }
    prefs.edit().putString("custom_sheets", root.toString()).apply()
}


@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Achievement(title: String, current: Int, target: Int) {
    val progress = (current.toFloat() / target.toFloat()).coerceIn(0f, 1f)
    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (current >= target) "🏆" else "🎯", fontSize = 20.sp)
                Spacer(Modifier.width(9.dp))
                Text(title, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${(progress * 100).toInt()}%", color = Accent, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)), color = Accent, trackColor = Color(0xFF292020))
            Text("${current.coerceAtMost(target)} / $target", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
        }
    }
}


private data class WeightRecord(val timestamp: Long, val day: String, val exercise: String, val kg: Float)

private fun loadWeightRecords(prefs: android.content.SharedPreferences): List<WeightRecord> = try {
    val array = JSONArray(prefs.getString("weight_records", "[]"))
    (0 until array.length()).map { index ->
        val item = array.getJSONObject(index)
        WeightRecord(item.getLong("timestamp"), item.getString("day"), item.getString("exercise"), item.getDouble("kg").toFloat())
    }
} catch (_: Exception) { emptyList() }

private fun saveWeightRecords(prefs: android.content.SharedPreferences, records: List<WeightRecord>) {
    val array = JSONArray()
    records.forEach { record ->
        array.put(org.json.JSONObject().put("timestamp", record.timestamp).put("day", record.day).put("exercise", record.exercise).put("kg", record.kg.toDouble()))
    }
    prefs.edit().putString("weight_records", array.toString()).apply()
}

@Composable
private fun WeightTrendChart(values: List<Float>) {
    if (values.isEmpty()) return
    val minValue = (values.minOrNull() ?: 0f).let { kotlin.math.floor(it - 2f).coerceAtLeast(0f) }
    val maxValue = (values.maxOrNull() ?: 1f).let { kotlin.math.ceil(it + 2f).coerceAtLeast(minValue + 1f) }
    Canvas(Modifier.fillMaxWidth().height(78.dp).padding(horizontal = 4.dp, vertical = 5.dp)) {
        val left = 8f
        val right = size.width - 8f
        val top = 6f
        val bottom = size.height - 6f
        drawLine(Color.DarkGray, androidx.compose.ui.geometry.Offset(left, bottom), androidx.compose.ui.geometry.Offset(right, bottom), 1.5f)
        val points = values.mapIndexed { index, value ->
            val x = if (values.size == 1) (left + right) / 2f else left + index.toFloat() / (values.size - 1) * (right - left)
            val y = bottom - ((value - minValue) / (maxValue - minValue)) * (bottom - top)
            androidx.compose.ui.geometry.Offset(x, y)
        }
        if (points.size == 1) drawCircle(Accent, radius = 5f, center = points.first())
        else {
            for (index in 0 until points.lastIndex) drawLine(Accent, points[index], points[index + 1], strokeWidth = 4f)
            points.forEach { drawCircle(Accent, radius = 4f, center = it) }
        }
    }
}
