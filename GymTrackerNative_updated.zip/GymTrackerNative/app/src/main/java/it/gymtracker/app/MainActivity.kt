package it.gymtracker.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF111111)
private val Red = Color(0xFFFF101B)
private val White = Color(0xFFF4F4F4)
private val Muted = Color(0xFFB8B8B8)

data class Exercise(val name: String, val sets: Int, val reps: String, val art: Int, val muscle: Int)

private val routines = mapOf(
    "A" to listOf(
        Exercise("LEG PRESS",4,"10",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PANCA PIANA",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("LAT AVANTI",4,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("ALZATE LAT",3,"12",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("PANCA SCOTT",4,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("PUSH DOWN",3,"12",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("PLANK",3,"30 sec",R.drawable.leg_press,R.drawable.leg_press_muscle)
    ),
    "B" to listOf(
        Exercise("LENTO MANUBRI",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("PULLEY",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG EX",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("CROCI",3,"12",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("ALZATE POST",3,"10",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("CURL AL CAVO",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("AB CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("SIDE PLANK",3,"20 sec",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("INVERSI VERTICAL",3,"15",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle)
    ),
    "C" to listOf(
        Exercise("CHEST*",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("REMATORE",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG CURL",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PUSH UP",4,"max",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CURL MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("FRENCH MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH GAMBE SU",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("HPX*",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle)
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var screen by remember { mutableStateOf("WORKOUT") }
    var checks by remember { mutableStateOf(loadChecks(prefs, day)) }
    var restSeconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }

    LaunchedEffect(timerActive, restSeconds) {
        while (timerActive && restSeconds > 0) { delay(1000); restSeconds -= 1 }
        if (restSeconds == 0) timerActive = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Column(
            Modifier.fillMaxSize().background(Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.gym_header),
                contentDescription = "Gym Tracker - Goku Black",
                modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("WORKOUT", "STORICO").forEach { tab ->
                    Button(
                        onClick = { screen = tab },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (screen == tab) Red else Color(0xFF171717))
                    ) { Text(tab, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                }
            }
            Spacer(Modifier.height(9.dp))

            when (screen) {
                "WORKOUT" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf("A", "B", "C").forEach { d ->
                            Button(
                                onClick = { day = d; prefs.edit().putString("day", d).apply(); checks = loadChecks(prefs, d) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (day == d) Red else Color(0xFF171717))
                            ) { Text("SCHEDA $d", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    val exercises = routines[day]!!
                    val total = exercises.sumOf { it.sets }
                    val done = checks.count { it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("▮", color = Red, fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("PROGRESSO  $done / $total SERIE", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),
                        color = Red, trackColor = Color(0xFF292020)
                    )
                    Spacer(Modifier.height(10.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                        itemsIndexed(exercises) { exIndex, ex ->
                            val start = exercises.take(exIndex).sumOf { it.sets }
                            ExerciseCard(ex, checks, start) { idx, checked ->
                                val updated = checks.toMutableList(); updated[idx] = checked; checks = updated
                                prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                                if (checked) { restSeconds = 90; timerActive = true }
                            }
                        }
                        item {
                            Button(
                                onClick = {
                                    val completed = checks.count { it }
                                    val entry = "Scheda $day — $completed/$total serie completate"
                                    history = (listOf(entry) + history.lines().filter { it.isNotBlank() }).take(50).joinToString("\n")
                                    prefs.edit().putString("history", history).apply()
                                    checks = List(total) { false }
                                    prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                                    timerActive = false; restSeconds = 0; screen = "STORICO"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Red),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) { Text("TERMINA ALLENAMENTO", fontWeight = FontWeight.Black) }
                        }
                    }
                }
                "STORICO" -> {
                    Text("CRONOLOGIA", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    if (history.isBlank()) Text("Gli allenamenti conclusi appariranno qui.", color = Muted)
                    else LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Text(line, color = White, modifier = Modifier.padding(14.dp))
                            }
                        }
                    }
                    OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }, modifier = Modifier.fillMaxWidth()) {
                        Text("CANCELLA CRONOLOGIA", color = Red)
                    }
                }
                else -> {
                    Text(screen, color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Questa sezione sarà disponibile in un prossimo aggiornamento.", color = Muted)
                    Spacer(Modifier.weight(1f))
                }
            }

            Row(
                Modifier.fillMaxWidth().background(Color(0xFF090909)).padding(top = 7.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("HOME", "STATISTICHE", "TRAGUARDI", "PROFILO").forEachIndexed { index, label ->
                    val target = when (index) { 0 -> "WORKOUT"; 1 -> "STATISTICHE"; 2 -> "TRAGUARDI"; else -> "PROFILO" }
                    TextButton(onClick = { screen = target }) {
                        Text(label, color = if ((index == 0 && screen == "WORKOUT") || (index == 1 && screen == "STATISTICHE") || (index == 2 && screen == "TRAGUARDI") || (index == 3 && screen == "PROFILO")) Red else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (timerActive && restSeconds > 0) {
            AlertDialog(
                onDismissRequest = { timerActive = false }, containerColor = Panel,
                title = { Text("RECUPERO", color = Red, fontWeight = FontWeight.Black) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60), color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                        Text("Respira. La prossima serie ti aspetta.", color = Muted)
                    }
                },
                confirmButton = { TextButton(onClick = { timerActive = false; restSeconds = 0 }) { Text("SALTA", color = Red) } },
                dismissButton = { TextButton(onClick = { timerActive = false }) { Text("NASCONDI", color = White) } }
            )
        }
    }
}

@Composable
private fun ExerciseCard(ex: Exercise, checks: List<Boolean>, start: Int, onCheck: (Int, Boolean) -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(126.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, Red, RoundedCornerShape(20.dp))
    ) {
        Image(painterResource(ex.art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.48f)))
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(ex.muscle), contentDescription = null,
                modifier = Modifier.width(66.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.width(7.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(ex.name, color = White, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text("${ex.sets} serie × ${ex.reps} ripetizioni", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    repeat(ex.sets) { s ->
                        val idx = start + s
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = checks.getOrElse(idx) { false },
                                onCheckedChange = { onCheck(idx, it) },
                                modifier = Modifier.size(30.dp),
                                colors = CheckboxDefaults.colors(checkedColor = Red, uncheckedColor = Muted, checkmarkColor = White)
                            )
                            Text("${s + 1}", color = if (checks.getOrElse(idx) { false }) Red else White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun loadChecks(prefs: android.content.SharedPreferences, day: String): List<Boolean> {
    val total = routines[day]!!.sumOf { it.sets }
    return try {
        val arr = JSONArray(prefs.getString("checks_$day", "[]"))
        List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false }
    } catch (_: Exception) { List(total) { false } }
}
