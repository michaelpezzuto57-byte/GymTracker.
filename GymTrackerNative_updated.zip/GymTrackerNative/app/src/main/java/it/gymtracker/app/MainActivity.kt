package it.gymtracker.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Red = Color(0xFFE31B23)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFFAAAAAA)

data class Exercise(val name: String, val sets: Int, val reps: String)
private val routines = mapOf(
    "A" to listOf(Exercise("LEG PRESS",4,"10"), Exercise("PANCA PIANA",4,"10"), Exercise("LAT AVANTI",4,"10"), Exercise("ALZATE LAT",3,"12"), Exercise("PANCA SCOTT",4,"10"), Exercise("PUSH DOWN",3,"12"), Exercise("CRUNCH",3,"15"), Exercise("CRUNCH INVERSO",3,"15"), Exercise("PLANK",3,"30 sec")),
    "B" to listOf(Exercise("LENTO MANUBRI",4,"10"), Exercise("PULLEY",3,"10"), Exercise("LEG EX",3,"12"), Exercise("CROCI",3,"12"), Exercise("ALZATE POST",3,"10"), Exercise("CURL AL CAVO",3,"10"), Exercise("AB CRUNCH",3,"15"), Exercise("SIDE PLANK",3,"20 sec"), Exercise("INVERSI VERTICAL",3,"15")),
    "C" to listOf(Exercise("CHEST*",4,"10"), Exercise("REMATORE",3,"10"), Exercise("LEG CURL",3,"12"), Exercise("PUSH UP",4,"max"), Exercise("CURL MANUBRI",3,"10"), Exercise("FRENCH MANUBRI",3,"10"), Exercise("CRUNCH GAMBE SU",3,"15"), Exercise("CRUNCH INVERSO",3,"15"), Exercise("HPX*",3,"12"))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var screen by remember { mutableStateOf("WORKOUT") }
    var checks by remember { mutableStateOf(loadChecks(prefs, day)) }
    var restSeconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    LaunchedEffect(timerActive, restSeconds) {
        while (timerActive && restSeconds > 0) { delay(1000); restSeconds -= 1 }
        if (restSeconds == 0) timerActive = false
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Column(Modifier.fillMaxSize().background(Black).windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 16.dp, vertical = 10.dp)) {
            Box(Modifier.fillMaxWidth().height(150.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.gym_header),
                    contentDescription = "Logo e sfondo Gym Tracker",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.12f)))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("WORKOUT", "STORICO").forEach { tab ->
                    Button(onClick = { screen = tab }, colors = ButtonDefaults.buttonColors(containerColor = if (screen == tab) Red else Panel), modifier = Modifier.weight(1f)) { Text(tab, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (screen == "WORKOUT") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("A", "B", "C").forEach { d ->
                        Button(onClick = { day = d; prefs.edit().putString("day", d).apply(); checks = loadChecks(prefs, d) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (day == d) Red else Panel)) { Text("SCHEDA $d", fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val total = routines[day]!!.sumOf { it.sets }
                val done = checks.count { it }
                Text("PROGRESSO  $done / $total SERIE", color = White, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat()/total }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Red, trackColor = Panel)
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    itemsIndexed(routines[day]!!) { exIndex, ex ->
                        val start = routines[day]!!.take(exIndex).sumOf { it.sets }
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(ex.name, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text("${ex.sets} serie  ×  ${ex.reps} ripetizioni", color = Muted, fontSize = 12.sp)
                                if (ex.name.contains("*")) Text("* Nome da verificare con la scheda originale", color = Muted, fontSize = 10.sp)
                                Spacer(Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    repeat(ex.sets) { s ->
                                        val idx = start + s
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Checkbox(checked = checks.getOrElse(idx) { false }, onCheckedChange = { checked ->
                                                val updated = checks.toMutableList(); updated[idx] = checked; checks = updated
                                                prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                                                if (checked) { restSeconds = 90; timerActive = true }
                                            }, colors = CheckboxDefaults.colors(checkedColor = Red, uncheckedColor = Muted))
                                            Text("${s+1}", color = if (checks.getOrElse(idx){false}) Red else White, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(4.dp))
                        Button(onClick = {
                            val completed = checks.count { it }
                            val entry = "Scheda $day — $completed/${checks.size} serie completate"
                            val newHistory = (listOf(entry) + history.lines().filter { it.isNotBlank() }).take(50).joinToString("\n")
                            history = newHistory; prefs.edit().putString("history", history).apply()
                            checks = List(total) { false }; prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                            timerActive = false; restSeconds = 0
                            screen = "STORICO"
                        }, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) { Text("TERMINA ALLENAMENTO", fontWeight = FontWeight.Black) }
                    }
                }
            } else {
                Text("CRONOLOGIA", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                if (history.isBlank()) Text("Gli allenamenti conclusi appariranno qui.", color = Muted)
                else LazyColumn(Modifier.weight(1f)) { itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line -> Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Text(line, color = White, modifier = Modifier.padding(14.dp)) } } }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }, modifier = Modifier.fillMaxWidth()) { Text("CANCELLA CRONOLOGIA", color = Red) }
            }
        }
        if (timerActive && restSeconds > 0) {
            AlertDialog(onDismissRequest = { timerActive = false }, containerColor = Panel,
                title = { Text("RECUPERO", color = Red, fontWeight = FontWeight.Black) },
                text = { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60), color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                    Text("Respira. La prossima serie ti aspetta.", color = Muted)
                } },
                confirmButton = { TextButton(onClick = { timerActive = false; restSeconds = 0 }) { Text("SALTA", color = Red) } },
                dismissButton = { TextButton(onClick = { timerActive = false }) { Text("NASCONDI", color = White) } })
        }
    }
}

private fun loadChecks(prefs: android.content.SharedPreferences, day: String): List<Boolean> {
    val total = routines[day]!!.sumOf { it.sets }
    return try { val arr = JSONArray(prefs.getString("checks_$day", "[]")); List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false } } catch (_: Exception) { List(total) { false } }
}
