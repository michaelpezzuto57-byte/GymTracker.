package it.gymtracker.app

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF111111)
private val Accent = mutableStateOf(Color(0xFFFF101B))
private val Red: Color get() = Accent.value
private val accentOptions = listOf(
    "ROSSO" to Color(0xFFFF101B),
    "VERDE" to Color(0xFF39D353),
    "BLU" to Color(0xFF268CFF),
    "VIOLA" to Color(0xFFB65CFF)
)
private val White = Color(0xFFF4F4F4)
private val Muted = Color(0xFFB8B8B8)

data class Exercise(val name: String, val sets: Int, val reps: String, val art: Int, val muscle: Int)
data class SetEntry(val done: Boolean = false, val kg: String = "", val reps: String = "")

private fun setKey(sheet: String, exercise: Int, set: Int) = "$sheet|$exercise|$set"
private fun loadSetEntries(prefs: android.content.SharedPreferences): Map<String, SetEntry> {
    return try {
        val root = org.json.JSONObject(prefs.getString("set_entries", "{}") ?: "{}")
        buildMap {
            root.keys().forEach { key ->
                val item = root.getJSONObject(key)
                put(key, SetEntry(item.optBoolean("done"), item.optString("kg"), item.optString("reps")))
            }
        }
    } catch (_: Exception) { emptyMap() }
}
private fun saveSetEntries(prefs: android.content.SharedPreferences, entries: Map<String, SetEntry>) {
    val root = org.json.JSONObject()
    entries.forEach { (key, value) -> root.put(key, org.json.JSONObject().put("done", value.done).put("kg", value.kg).put("reps", value.reps)) }
    prefs.edit().putString("set_entries", root.toString()).apply()
}

private val routines = mapOf(
    "A" to listOf(
        Exercise("LEG PRESS",4,"10",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PANCA PIANA",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("LAT AVANTI",4,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("ALZATE LAT",3,"12",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("PANCA SCOTT",4,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("PUSH DOWN",3,"12",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("PLANK",3,"30 sec",R.drawable.leg_press,R.drawable.leg_press_muscle)
    ),
    "B" to listOf(
        Exercise("LENTO MANUBRI",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("PULLEY",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG EX",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("CROCI",3,"12",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("ALZATE POST",3,"10",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("CURL AL CAVO",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("AB CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("SIDE PLANK",3,"20 sec",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("INVERSI VERTICAL",3,"15",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle)
    ),
    "C" to listOf(
        Exercise("CHEST*",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("REMATORE",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG CURL",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PUSH UP",4,"max",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CURL MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("FRENCH MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH GAMBE SU",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("HPX*",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle)
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var selectedAccent by remember {
        mutableStateOf(prefs.getString("accent", "ROSSO") ?: "ROSSO")
    }
    SideEffect {
        Accent.value = accentOptions.firstOrNull { it.first == selectedAccent }?.second ?: accentOptions.first().second
    }
    var screen by remember { mutableStateOf("HOME") }
    var drawerOpen by remember { mutableStateOf(false) }
    var defaultWeights by remember { mutableStateOf(loadDefaultWeights(prefs)) }
    var customSheets by remember { mutableStateOf(loadCustomSheets(prefs)) }
    var checks by remember { mutableStateOf(loadChecks(prefs, day, customSheets)) }
    var setEntries by remember { mutableStateOf(loadSetEntries(prefs)) }
    var restSeconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var showImport by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf("") }
    var importedName by remember { mutableStateOf("NUOVA SCHEDA") }
    var ocrBusy by remember { mutableStateOf(false) }

    fun recognizeImage(image: InputImage) {
        ocrBusy = true
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result -> ocrText = result.text; showImport = true; ocrBusy = false }
            .addOnFailureListener { ocrText = "Non sono riuscito a leggere il testo. Puoi inserirlo manualmente qui."; showImport = true; ocrBusy = false }
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try { recognizeImage(InputImage.fromFilePath(context, uri)) } catch (_: Exception) { ocrText = "Impossibile aprire la foto."; showImport = true }
    }
    val cameraPicker = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) recognizeImage(InputImage.fromBitmap(bitmap, 0))
    }

    LaunchedEffect(timerActive, restSeconds) {
        while (timerActive && restSeconds > 0) { delay(1000); restSeconds -= 1 }
        if (restSeconds == 0) timerActive = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Column(
            Modifier.fillMaxSize().background(Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("☰", color = Red, fontSize = 30.sp, modifier = Modifier.clickable { drawerOpen = !drawerOpen }.padding(8.dp))
                Image(painter = painterResource(R.drawable.gym_header), contentDescription = "GymTracker Goku Black", modifier = Modifier.weight(1f).height(76.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            }
            Spacer(Modifier.height(8.dp))

            when (screen) {
                "HOME" -> {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Box(Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(18.dp))) {
                                Image(painter = painterResource(R.drawable.gym_header), contentDescription = "Sfondo Goku Black", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                Column(Modifier.fillMaxSize().background(Color(0x99000000)).padding(16.dp), verticalArrangement = Arrangement.Bottom) {
                                    Text("BENVENUTO", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                                    Text("Il tuo percorso verso il massimo risultato", color = White)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = { screen = "WORKOUT" }, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) { Text("ALLENAMENTO RAPIDO") }
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("LE TUE SCHEDE", color = White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("A", "B", "C").forEach { code ->
                                            Button(onClick = { day = code; prefs.edit().putString("day", code).apply(); checks = loadChecks(prefs, code, customSheets); screen = "WORKOUT" }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("SCHEDA $code") }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("I MIEI PESI", color = White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                                    val allExercises = (routines.values.flatten() + customSheets.values.flatten()).distinctBy { it.name }
                                    allExercises.forEach { ex ->
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(ex.name, color = White, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                            OutlinedTextField(value = defaultWeights[ex.name] ?: "", onValueChange = { value ->
                                                defaultWeights = defaultWeights.toMutableMap().also { it[ex.name] = value }
                                                saveDefaultWeights(prefs, defaultWeights)
                                            }, modifier = Modifier.width(105.dp), singleLine = true, label = { Text("KG", fontSize = 10.sp) }, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                        }
                                    }
                                    Text("Modifica qui i carichi di riferimento: li ritroverai pronti nelle schede.", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                "WORKOUT" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        (listOf("A", "B", "C") + customSheets.keys).forEach { d ->
                            Button(
                                onClick = { day = d; prefs.edit().putString("day", d).apply(); checks = loadChecks(prefs, d, customSheets) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (day == d) Red else Color(0xFF171717))
                            ) { Text("SCHEDA $d", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { cameraPicker.launch(null) }, modifier = Modifier.weight(1f)) { Text("FOTOCAMERA", color = Red, fontSize = 11.sp) }
                        OutlinedButton(onClick = { galleryPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("GALLERIA", color = Red, fontSize = 11.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    val exercises = customSheets[day] ?: routines[day] ?: emptyList()
                    val total = exercises.sumOf { it.sets }
                    val done = checks.count { it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("▮", color = Red, fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("PROGRESSO  $done / $total SERIE", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),
                        color = Red, trackColor = Color(0xFF292020)
                    )
                    Spacer(Modifier.height(10.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                        itemsIndexed(exercises) { exIndex, ex ->
                            val start = exercises.take(exIndex).sumOf { it.sets }
                            ExerciseCard(ex, exIndex, day, setEntries) { key, entry ->
                                setEntries = setEntries.toMutableMap().also { it[key] = entry }
                                saveSetEntries(prefs, setEntries)
                                val updated = checks.toMutableList()
                                val localIndex = key.substringAfterLast('|').toIntOrNull() ?: 0
                                val globalIndex = start + localIndex
                                if (globalIndex in updated.indices) {
                                    updated[globalIndex] = entry.done
                                    checks = updated
                                    prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                                }
                                if (entry.done) { restSeconds = 90; timerActive = true }
                            }
                        }
                        item {
                            Button(
                                onClick = {
                                    val completed = checks.count { it }
                                    val stamp = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.ITALY).format(java.util.Date())
                                    val detail = exercises.mapIndexed { ei, ex ->
                                        val sets = (0 until ex.sets).map { si -> setEntries[setKey(day, ei, si)] ?: SetEntry() }
                                        "${ex.name}: " + sets.mapIndexed { si, v -> "${si + 1}) ${v.kg.ifBlank { "—" }} kg × ${v.reps.ifBlank { ex.reps }}${if (v.done) " ✓" else ""}" }.joinToString("; ")
                                    }.joinToString("\n")
                                    val entry = "[$stamp] Scheda $day — $completed/$total serie\n$detail"
                                    history = (listOf(entry) + history.split("\n\n").filter { it.isNotBlank() }).take(50).joinToString("\n\n")
                                    prefs.edit().putString("history", history).apply()
                                    val cleared = setEntries.toMutableMap()
                                    exercises.forEachIndexed { ei, ex -> (0 until ex.sets).forEach { si -> cleared.remove(setKey(day, ei, si)) } }
                                    setEntries = cleared; saveSetEntries(prefs, setEntries)
                                    checks = List(total) { false }
                                    prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                                    timerActive = false; restSeconds = 0; screen = "STORICO"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Red),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) { Text("TERMINA ALLENAMENTO", fontWeight = FontWeight.Black) }
                        }
                    }
                }
                "STORICO" -> {
                    Text("CRONOLOGIA", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    if (history.isBlank()) Text("Gli allenamenti conclusi appariranno qui.", color = Muted)
                    else LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Text(line, color = White, modifier = Modifier.padding(14.dp))
                            }
                        }
                    }
                    OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }, modifier = Modifier.fillMaxWidth()) {
                        Text("CANCELLA CRONOLOGIA", color = Red)
                    }
                }
                "STATISTICHE" -> {
                    val sessions = Regex("\\[\\d{2}/\\d{2}/\\d{4} ").findAll(history).count()
                    val completedSets = Regex("\\d+\\) [^\\n]*✓").findAll(history).count()
                    val totalSets = Regex("\\d+\\) [^\\n]* kg ×").findAll(history).count()
                    Text("LE TUE STATISTICHE", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("ALLENAMENTI", sessions.toString(), Modifier.weight(1f))
                        StatCard("SERIE REGISTRATE", totalSets.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    StatCard("SERIE COMPLETATE", completedSets.toString(), Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Text("Le statistiche vengono calcolate dagli allenamenti che salvi con ‘TERMINA ALLENAMENTO’. Per confrontare i carichi nel tempo, registra kg e ripetizioni in ogni serie.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                }
                "PROFILO" -> {
                    Text("PROFILO", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(12.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("GYM TRACKER", color = Red, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text("Profilo locale • dati salvati su questo dispositivo", color = White)
                            Text("Schede predefinite: A, B e C", color = Muted)
                            Text("Schede personalizzate: ${customSheets.size}", color = Muted)
                            Text("Allenamenti nello storico: ${Regex("\\[\\d{2}/\\d{2}/\\d{4} ").findAll(history).count()}", color = Muted)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("TEMA DELL'APP", color = White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text("Scegli il colore principale", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        accentOptions.chunked(2).forEach { rowOptions ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                rowOptions.forEach { (name, color) ->
                                    OutlinedButton(
                                        onClick = { selectedAccent = name; prefs.edit().putString("accent", name).apply(); Accent.value = color },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
                                        border = androidx.compose.foundation.BorderStroke(if (selectedAccent == name) 2.dp else 1.dp, color)
                                    ) { Text(if (selectedAccent == name) "✓ $name" else name, fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("I dati dell'app restano nella memoria locale del telefono. Se cancelli i dati dell'app o la disinstalli, lo storico potrebbe andare perso.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                }
            }

            if (drawerOpen) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF100707)), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("GYMTRACKER", color = Red, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        listOf("HOME" to "Home", "WORKOUT" to "Allenamento", "STORICO" to "Storico", "STATISTICHE" to "Statistiche", "PROFILO" to "Profilo").forEach { (target, label) ->
                            Text(label, color = if (screen == target) Red else White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { screen = target; drawerOpen = false }.padding(12.dp))
                        }
                    }
                }
            }
        }

        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false },
                containerColor = Panel,
                title = { Text("CONTROLLA LA SCHEDA", color = Red, fontWeight = FontWeight.Black) },
                text = {
                    Column {
                        Text("Controlla e correggi il testo riconosciuto prima di salvarlo.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = importedName, onValueChange = { importedName = it }, label = { Text("Nome della nuova scheda") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = ocrText, onValueChange = { ocrText = it }, label = { Text("Testo riconosciuto (modificabile)") }, minLines = 5, maxLines = 9)
                        Text("Suggerimento: scrivi un esercizio per riga, ad esempio Panca piana 4x10.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = parseImportedExercises(ocrText)
                        val newName = importedName.trim()
                        val reservedName = newName.equals("A", true) || newName.equals("B", true) || newName.equals("C", true)
                        if (newName.isNotBlank() && !reservedName && parsed.isNotEmpty()) {
                            customSheets = customSheets + (newName to parsed)
                            saveCustomSheets(prefs, customSheets)
                            day = newName; prefs.edit().putString("day", day).apply()
                            checks = loadChecks(prefs, day, customSheets)
                            prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                            showImport = false
                        }
                    }) { Text("SALVA NUOVA SCHEDA", color = Red) }
                },
                dismissButton = { TextButton(onClick = { showImport = false }) { Text("ANNULLA", color = White) } }
            )
        }

        if (timerActive && restSeconds > 0) {
            AlertDialog(
                onDismissRequest = { timerActive = false }, containerColor = Panel,
                title = { Text("RECUPERO", color = Red, fontWeight = FontWeight.Black) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60), color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                        Text("Respira. La prossima serie ti aspetta.", color = Muted)
                    }
                },
                confirmButton = { TextButton(onClick = { timerActive = false; restSeconds = 0 }) { Text("SALTA", color = Red) } },
                dismissButton = { TextButton(onClick = { timerActive = false }) { Text("NASCONDI", color = White) } }
            )
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Red, fontSize = 28.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ExerciseCard(ex: Exercise, exerciseIndex: Int, sheet: String, entries: Map<String, SetEntry>, onChange: (String, SetEntry) -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).border(1.5.dp, Red, RoundedCornerShape(18.dp)).background(Panel).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(ex.muscle), null, Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(ex.name, color = White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Text("${ex.sets} serie × ${ex.reps} ripetizioni previste", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SERIE", color = Muted, modifier = Modifier.weight(.7f), fontSize = 10.sp)
            Text("KG", color = Muted, modifier = Modifier.weight(1f), fontSize = 10.sp)
            Text("RIP.", color = Muted, modifier = Modifier.weight(1f), fontSize = 10.sp)
            Text("FATTA", color = Muted, modifier = Modifier.weight(.8f), fontSize = 10.sp)
        }
        repeat(ex.sets) { si ->
            val key = setKey(sheet, exerciseIndex, si)
            val value = entries[key] ?: SetEntry()
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${si + 1}", color = White, modifier = Modifier.weight(.7f))
                OutlinedTextField(value.kg, { onChange(key, value.copy(kg = it)) }, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(value.reps, { onChange(key, value.copy(reps = it)) }, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp), placeholder = { Text(ex.reps, fontSize = 11.sp) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Checkbox(value.done, { onChange(key, value.copy(done = it)) }, modifier = Modifier.weight(.8f), colors = CheckboxDefaults.colors(checkedColor = Red, uncheckedColor = Muted, checkmarkColor = White))
            }
        }
    }
}

private fun loadDefaultWeights(prefs: android.content.SharedPreferences): Map<String, String> = try {
    val root = org.json.JSONObject(prefs.getString("default_weights", "{}") ?: "{}")
    buildMap { root.keys().forEach { key -> put(key, root.optString(key)) } }
} catch (_: Exception) { emptyMap() }

private fun saveDefaultWeights(prefs: android.content.SharedPreferences, weights: Map<String, String>) {
    val root = org.json.JSONObject()
    weights.forEach { (name, kg) -> root.put(name, kg) }
    prefs.edit().putString("default_weights", root.toString()).apply()
}

private fun loadChecks(
    prefs: android.content.SharedPreferences,
    day: String,
    customSheets: Map<String, List<Exercise>>
): List<Boolean> {
    val total = (customSheets[day] ?: routines[day] ?: emptyList()).sumOf { it.sets }
    return try {
        val arr = JSONArray(prefs.getString("checks_$day", "[]"))
        List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false }
    } catch (_: Exception) { List(total) { false } }
}


private fun parseImportedExercises(text: String): List<Exercise> {
    return text.lines().mapNotNull { line ->
        val clean = line.trim().trim('-', '•', '·')
        val match = Regex("^(.*?)(?:\\s+|\\s*[-:]\\s*)(\\d{1,2})\\s*[xX×]\\s*(\\d{1,3}(?:\\s*sec)?)$", RegexOption.IGNORE_CASE).find(clean)
            ?: Regex("^(.*?)\\s+(\\d{1,2})\\s*[xX×]\\s*(\\d{1,3})$", RegexOption.IGNORE_CASE).find(clean)
        if (match != null && match.groupValues[1].isNotBlank()) {
            Exercise(match.groupValues[1].trim().uppercase(), match.groupValues[2].toInt().coerceIn(1, 20), match.groupValues[3].trim(), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
        } else null
    }.distinctBy { it.name }.take(40)
}

private fun loadCustomSheets(prefs: android.content.SharedPreferences): Map<String, List<Exercise>> {
    return try {
        val root = org.json.JSONObject(prefs.getString("custom_sheets", "{}") ?: "{}")
        val result = linkedMapOf<String, List<Exercise>>()
        root.keys().forEach { key ->
            val arr = root.getJSONArray(key)
            result[key] = (0 until arr.length()).map { i ->
                val item = arr.getJSONObject(i)
                Exercise(item.getString("name"), item.getInt("sets"), item.getString("reps"), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
            }
        }
        result
    } catch (_: Exception) { emptyMap() }
}

private fun saveCustomSheets(prefs: android.content.SharedPreferences, sheets: Map<String, List<Exercise>>) {
    val root = org.json.JSONObject()
    sheets.forEach { (name, exercises) ->
        val arr = JSONArray()
        exercises.forEach { ex -> arr.put(org.json.JSONObject().put("name", ex.name).put("sets", ex.sets).put("reps", ex.reps)) }
        root.put(name, arr)
    }
    prefs.edit().putString("custom_sheets", root.toString()).apply()
}
