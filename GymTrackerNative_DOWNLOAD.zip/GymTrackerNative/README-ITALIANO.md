# Gym Tracker – versione aggiornata

## Funzioni incluse
- Allenamento con schede A, B e C e controllo delle serie.
- Timer recupero da 90 secondi.
- Cronologia degli allenamenti salvata sul dispositivo.
- Importazione di una scheda tramite fotocamera o galleria.
- Riconoscimento testo OCR con ML Kit e anteprima modificabile prima del salvataggio.
- Creazione di schede personalizzate senza sovrascrivere A, B e C.
- Sezione Statistiche con conteggio degli allenamenti e delle serie registrate.
- Sezione Traguardi con obiettivi progressivi.
- Profilo con nome atleta e obiettivo personalizzabili.
- Icona launcher personalizzata Gym Tracker in stile nero/rosso.

## Compilazione
Il workflow GitHub Actions incluso compila `assembleDebug` e pubblica l'APK come artifact `Gym-Tracker-APK`.
