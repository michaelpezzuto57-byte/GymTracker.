package it.gymtracker.app

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.OutlinedTextField
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF111111)
private val Red = Color(0xFFFF101B)
private val White = Color(0xFFF4F4F4)
private val Muted = Color(0xFFB8B8B8)

data class Exercise(val name: String, val sets: Int, val reps: String, val art: Int, val muscle: Int)
data class SetRecord(val weight: String = "", val reps: String = "")

private fun recordKey(day: String, exercise: Int, set: Int) = "$day|$exercise|$set"
private fun loadSetRecords(prefs: android.content.SharedPreferences): Map<String, SetRecord> {
    return try {
        val root = org.json.JSONObject(prefs.getString("set_records", "{}") ?: "{}")
        buildMap {
            root.keys().forEach { key ->
                val item = root.getJSONObject(key)
                put(key, SetRecord(item.optString("weight"), item.optString("reps")))
            }
        }
    } catch (_: Exception) { emptyMap() }
}
private fun saveSetRecords(prefs: android.content.SharedPreferences, records: Map<String, SetRecord>) {
    val root = org.json.JSONObject()
    records.forEach { (key, value) -> root.put(key, org.json.JSONObject().put("weight", value.weight).put("reps", value.reps)) }
    prefs.edit().putString("set_records", root.toString()).apply()
}

private val routines = mapOf(
    "A" to listOf(
        Exercise("LEG PRESS",4,"10",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PANCA PIANA",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("LAT AVANTI",4,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("ALZATE LAT",3,"12",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("PANCA SCOTT",4,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("PUSH DOWN",3,"12",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("PLANK",3,"30 sec",R.drawable.leg_press,R.drawable.leg_press_muscle)
    ),
    "B" to listOf(
        Exercise("LENTO MANUBRI",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("PULLEY",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG EX",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("CROCI",3,"12",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("ALZATE POST",3,"10",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle),
        Exercise("CURL AL CAVO",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("AB CRUNCH",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("SIDE PLANK",3,"20 sec",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("INVERSI VERTICAL",3,"15",R.drawable.alzate_lat,R.drawable.alzate_lat_muscle)
    ),
    "C" to listOf(
        Exercise("CHEST*",4,"10",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("REMATORE",3,"10",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("LEG CURL",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle),
        Exercise("PUSH UP",4,"max",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("CURL MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("FRENCH MANUBRI",3,"10",R.drawable.panca_scott,R.drawable.panca_scott_muscle),
        Exercise("CRUNCH GAMBE SU",3,"15",R.drawable.lat_avanti,R.drawable.lat_avanti_muscle),
        Exercise("CRUNCH INVERSO",3,"15",R.drawable.panca_piana,R.drawable.panca_piana_muscle),
        Exercise("HPX*",3,"12",R.drawable.leg_press,R.drawable.leg_press_muscle)
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymTrackerApp(this) }
    }
}

@Composable
fun GymTrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("gym_tracker", Context.MODE_PRIVATE) }
    var day by remember { mutableStateOf(prefs.getString("day", "A") ?: "A") }
    var screen by remember { mutableStateOf("WORKOUT") }
    var customSheets by remember { mutableStateOf(loadCustomSheets(prefs)) }
    var checks by remember { mutableStateOf(loadChecks(prefs, day, customSheets)) }
    var restSeconds by remember { mutableIntStateOf(0) }
    var timerActive by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var setRecords by remember { mutableStateOf(loadSetRecords(prefs)) }
    var showImport by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf("") }
    var importedName by remember { mutableStateOf("NUOVA SCHEDA") }
    var ocrBusy by remember { mutableStateOf(false) }

    fun recognizeImage(image: InputImage) {
        ocrBusy = true
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result -> ocrText = result.text; showImport = true; ocrBusy = false }
            .addOnFailureListener { ocrText = "Non sono riuscito a leggere il testo. Puoi inserirlo manualmente qui."; showImport = true; ocrBusy = false }
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try { recognizeImage(InputImage.fromFilePath(context, uri)) } catch (_: Exception) { ocrText = "Impossibile aprire la foto."; showImport = true }
    }
    val cameraPicker = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) recognizeImage(InputImage.fromBitmap(bitmap, 0))
    }

    LaunchedEffect(timerActive, restSeconds) {
        while (timerActive && restSeconds > 0) { delay(1000); restSeconds -= 1 }
        if (restSeconds == 0) timerActive = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Black, surface = Panel, onSurface = White)) {
        Column(
            Modifier.fillMaxSize().background(Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.gym_header),
                contentDescription = "Gym Tracker - Goku Black",
                modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("WORKOUT", "STORICO").forEach { tab ->
                    Button(
                        onClick = { screen = tab },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (screen == tab) Red else Color(0xFF171717))
                    ) { Text(tab, color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                }
            }
            Spacer(Modifier.height(9.dp))

            when (screen) {
                "WORKOUT" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        (listOf("A", "B", "C") + customSheets.keys).forEach { d ->
                            Button(
                                onClick = { day = d; prefs.edit().putString("day", d).apply(); checks = loadChecks(prefs, d, customSheets) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                shape = RoundedCornerShape(24.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = if (day == d) Red else Color(0xFF171717))
                            ) { Text("SCHEDA $d", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { cameraPicker.launch(null) }, modifier = Modifier.weight(1f)) { Text("FOTOCAMERA", color = Red, fontSize = 11.sp) }
                        OutlinedButton(onClick = { galleryPicker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("GALLERIA", color = Red, fontSize = 11.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    val exercises = customSheets[day] ?: routines[day] ?: emptyList()
                    val total = exercises.sumOf { it.sets }
                    val done = checks.count { it }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("▮", color = Red, fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("PROGRESSO  $done / $total SERIE", color = White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)),
                        color = Red, trackColor = Color(0xFF292020)
                    )
                    Spacer(Modifier.height(10.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.weight(1f)) {
                        itemsIndexed(exercises) { exIndex, ex ->
                            val start = exercises.take(exIndex).sumOf { it.sets }
                            ExerciseCard(
                                ex = ex, checks = checks, start = start, exerciseIndex = exIndex,
                                records = setRecords, day = day,
                                onCheck = { idx, checked ->
                                    val updated = checks.toMutableList(); updated[idx] = checked; checks = updated
                                    prefs.edit().putString("checks_$day", JSONArray(updated).toString()).apply()
                                    if (checked) { restSeconds = 90; timerActive = true }
                                },
                                onRecordChange = { key, record ->
                                    setRecords = setRecords.toMutableMap().apply { put(key, record) }
                                    saveSetRecords(prefs, setRecords)
                                }
                            )
                        }
                        item {
                            Button(
                                onClick = {
                                    val completed = checks.count { it }
                                    val entry = "Scheda $day — $completed/$total serie completate"
                                    history = (listOf(entry) + history.lines().filter { it.isNotBlank() }).take(50).joinToString("\n")
                                    prefs.edit().putString("history", history).apply()
                                    checks = List(total) { false }
                                    prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                                    timerActive = false; restSeconds = 0; screen = "STORICO"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Red),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                shape = RoundedCornerShape(24.dp)
                            ) { Text("TERMINA ALLENAMENTO", fontWeight = FontWeight.Black) }
                        }
                    }
                }
                "STORICO" -> {
                    Text("CRONOLOGIA", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    if (history.isBlank()) Text("Gli allenamenti conclusi appariranno qui.", color = Muted)
                    else LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(history.lines().filter { it.isNotBlank() }) { _, line ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                                Text(line, color = White, modifier = Modifier.padding(14.dp))
                            }
                        }
                    }
                    OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }, modifier = Modifier.fillMaxWidth()) {
                        Text("CANCELLA CRONOLOGIA", color = Red)
                    }
                }
                "STATISTICHE" -> {
                    val recorded = setRecords.values.filter { it.weight.isNotBlank() || it.reps.isNotBlank() }
                    val weights = setRecords.values.mapNotNull { it.weight.replace(',', '.').toFloatOrNull() }
                    val maxWeight = weights.maxOrNull()
                    val completed = routines.keys.sumOf { key -> loadChecks(prefs, key, customSheets).count { it } }
                    Text("STATISTICHE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("SERIE REGISTRATE", recorded.size.toString(), Modifier.weight(1f))
                        StatTile("SERIE COMPLETATE", completed.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("PESO MASSIMO", maxWeight?.let { "${it} kg" } ?: "—", Modifier.weight(1f))
                        StatTile("SCHEDE PERSONALI", customSheets.size.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("ULTIMI PESI INSERITI", color = Red, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    val recent = setRecords.entries.filter { it.value.weight.isNotBlank() || it.value.reps.isNotBlank() }.takeLast(20).reversed()
                    if (recent.isEmpty()) Text("Inserisci kg e ripetizioni durante un allenamento per iniziare a creare le statistiche.", color = Muted)
                    else LazyColumn(Modifier.weight(1f)) {
                        itemsIndexed(recent) { _, item ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(item.key.replace('|', ' ').replace(Regex("\\s+"), " · "), color = White, fontWeight = FontWeight.Bold)
                                    Text("${item.value.weight.ifBlank { "—" }} kg  ·  ${item.value.reps.ifBlank { "—" }} ripetizioni", color = Muted)
                                }
                            }
                        }
                    }
                }
                "TRAGUARDI" -> {
                    Text("TRAGUARDI", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Text("Continua a registrare gli allenamenti: qui potrai seguire i tuoi progressi.", color = Muted)
                    Spacer(Modifier.weight(1f))
                }
                "PROFILO" -> {
                    Text("PROFILO", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Text("Gym Tracker · dati salvati sul dispositivo", color = Muted)
                    Spacer(Modifier.weight(1f))
                }
                else -> { Text(screen, color = White); Spacer(Modifier.weight(1f)) }
            }

            Row(
                Modifier.fillMaxWidth().background(Color(0xFF090909)).padding(top = 7.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("HOME", "STATISTICHE", "TRAGUARDI", "PROFILO").forEachIndexed { index, label ->
                    val target = when (index) { 0 -> "WORKOUT"; 1 -> "STATISTICHE"; 2 -> "TRAGUARDI"; else -> "PROFILO" }
                    TextButton(onClick = { screen = target }) {
                        Text(label, color = if ((index == 0 && screen == "WORKOUT") || (index == 1 && screen == "STATISTICHE") || (index == 2 && screen == "TRAGUARDI") || (index == 3 && screen == "PROFILO")) Red else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false },
                containerColor = Panel,
                title = { Text("CONTROLLA LA SCHEDA", color = Red, fontWeight = FontWeight.Black) },
                text = {
                    Column {
                        Text("Controlla e correggi il testo riconosciuto prima di salvarlo.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = importedName, onValueChange = { importedName = it }, label = { Text("Nome della nuova scheda") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = ocrText, onValueChange = { ocrText = it }, label = { Text("Testo riconosciuto (modificabile)") }, minLines = 5, maxLines = 9)
                        Text("Suggerimento: scrivi un esercizio per riga, ad esempio Panca piana 4x10.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = parseImportedExercises(ocrText)
                        val newName = importedName.trim()
                        val reservedName = newName.equals("A", true) || newName.equals("B", true) || newName.equals("C", true)
                        if (newName.isNotBlank() && !reservedName && parsed.isNotEmpty()) {
                            customSheets = customSheets + (newName to parsed)
                            saveCustomSheets(prefs, customSheets)
                            day = newName; prefs.edit().putString("day", day).apply()
                            checks = loadChecks(prefs, day, customSheets)
                            prefs.edit().putString("checks_$day", JSONArray(checks).toString()).apply()
                            showImport = false
                        }
                    }) { Text("SALVA NUOVA SCHEDA", color = Red) }
                },
                dismissButton = { TextButton(onClick = { showImport = false }) { Text("ANNULLA", color = White) } }
            )
        }

        if (timerActive && restSeconds > 0) {
            AlertDialog(
                onDismissRequest = { timerActive = false }, containerColor = Panel,
                title = { Text("RECUPERO", color = Red, fontWeight = FontWeight.Black) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(String.format("%02d:%02d", restSeconds / 60, restSeconds % 60), color = White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                        Text("Respira. La prossima serie ti aspetta.", color = Muted)
                    }
                },
                confirmButton = { TextButton(onClick = { timerActive = false; restSeconds = 0 }) { Text("SALTA", color = Red) } },
                dismissButton = { TextButton(onClick = { timerActive = false }) { Text("NASCONDI", color = White) } }
            )
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = White, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ExerciseCard(
    ex: Exercise, checks: List<Boolean>, start: Int, exerciseIndex: Int, day: String,
    records: Map<String, SetRecord>, onCheck: (Int, Boolean) -> Unit,
    onRecordChange: (String, SetRecord) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().border(2.dp, Red, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(ex.muscle), null, Modifier.size(62.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(ex.name, color = White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                    Text("${ex.sets} serie × ${ex.reps} ripetizioni", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            ex.sets.let { count ->
                repeat(count) { setIndex ->
                    val flatIndex = start + setIndex
                    val key = recordKey(day, exerciseIndex, setIndex)
                    val record = records[key] ?: SetRecord()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Checkbox(
                            checked = checks.getOrElse(flatIndex) { false },
                            onCheckedChange = { onCheck(flatIndex, it) },
                            modifier = Modifier.size(34.dp),
                            colors = CheckboxDefaults.colors(checkedColor = Red, uncheckedColor = Muted, checkmarkColor = White)
                        )
                        Text("${setIndex + 1}", color = White, fontSize = 12.sp, modifier = Modifier.width(14.dp))
                        OutlinedTextField(
                            value = record.weight, onValueChange = { onRecordChange(key, record.copy(weight = it.filter { c -> c.isDigit() || c == '.' || c == ',' })) },
                            label = { Text("Kg") }, singleLine = true, modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp)
                        )
                        OutlinedTextField(
                            value = record.reps, onValueChange = { onRecordChange(key, record.copy(reps = it.filter(Char::isDigit))) },
                            label = { Text("Rip.") }, singleLine = true, modifier = Modifier.weight(1f),
                            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp)
                        )
                    }
                }
            }
        }
    }
}

private fun loadChecks(
    prefs: android.content.SharedPreferences,
    day: String,
    customSheets: Map<String, List<Exercise>>
): List<Boolean> {
    val total = (customSheets[day] ?: routines[day] ?: emptyList()).sumOf { it.sets }
    return try {
        val arr = JSONArray(prefs.getString("checks_$day", "[]"))
        List(total) { i -> if (i < arr.length()) arr.optBoolean(i, false) else false }
    } catch (_: Exception) { List(total) { false } }
}


private fun parseImportedExercises(text: String): List<Exercise> {
    return text.lines().mapNotNull { line ->
        val clean = line.trim().trim('-', '•', '·')
        val match = Regex("^(.*?)(?:\\s+|\\s*[-:]\\s*)(\\d{1,2})\\s*[xX×]\\s*(\\d{1,3}(?:\\s*sec)?)$", RegexOption.IGNORE_CASE).find(clean)
            ?: Regex("^(.*?)\\s+(\\d{1,2})\\s*[xX×]\\s*(\\d{1,3})$", RegexOption.IGNORE_CASE).find(clean)
        if (match != null && match.groupValues[1].isNotBlank()) {
            Exercise(match.groupValues[1].trim().uppercase(), match.groupValues[2].toInt().coerceIn(1, 20), match.groupValues[3].trim(), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
        } else null
    }.distinctBy { it.name }.take(40)
}

private fun loadCustomSheets(prefs: android.content.SharedPreferences): Map<String, List<Exercise>> {
    return try {
        val root = org.json.JSONObject(prefs.getString("custom_sheets", "{}") ?: "{}")
        val result = linkedMapOf<String, List<Exercise>>()
        root.keys().forEach { key ->
            val arr = root.getJSONArray(key)
            result[key] = (0 until arr.length()).map { i ->
                val item = arr.getJSONObject(i)
                Exercise(item.getString("name"), item.getInt("sets"), item.getString("reps"), R.drawable.panca_piana, R.drawable.panca_piana_muscle)
            }
        }
        result
    } catch (_: Exception) { emptyMap() }
}

private fun saveCustomSheets(prefs: android.content.SharedPreferences, sheets: Map<String, List<Exercise>>) {
    val root = org.json.JSONObject()
    sheets.forEach { (name, exercises) ->
        val arr = JSONArray()
        exercises.forEach { ex -> arr.put(org.json.JSONObject().put("name", ex.name).put("sets", ex.sets).put("reps", ex.reps)) }
        root.put(name, arr)
    }
    prefs.edit().putString("custom_sheets", root.toString()).apply()
}
